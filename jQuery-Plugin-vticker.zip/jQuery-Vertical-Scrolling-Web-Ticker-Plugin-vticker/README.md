# VTicker

This project is a fork of original vTicker jQuery plugin implentation by JugBit (MIT Licensed):

http://www.jugbit.com/jquery-vticker-vertical-news-ticker/

This project uses the original code as a starting point but uses a method based implementation. 

Compared to the original, it does not support fading and the direction option is removed as the animation direction is based on next or previous item: up for next; and down for previous.

Please consider supporting the original author who has a Donate button on their page.

[You should follow me on Twitter @richhollis](https://twitter.com/intent/user?screen_name=richhollis)

## Using

Please see the demo site for all documentation and demos:

[![vTicker site](https://raw.github.com/richhollis/vticker/master/vticker.png "vTicker site")](http://richhollis.github.com/vticker/)
